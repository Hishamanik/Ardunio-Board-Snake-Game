#include <Arduino.h>
#include <Adafruit_GFX.h>
//#include <MCUFRIEND_kbv.h>

//MCUFRIEND_kbv tft;

class SnakeSeg {
public:
	int xPos, yPos;
	SnakeSeg();

	void move(int X, int Y);
	void setPos(int X, int Y);

private:
	





};